// hide

$(document).ready(function () {
    $(".x_of_click").click(function () {
        $(".buy_now_pay_letter").hide();
    });
});


$(document).ready(function () {
    $(".x_of_clickt").click(function () {
        $(".buy_now_pay_lettert").hide();
    });
});

$(document).ready(function () {
    $(".popup_button").click(function () {
        $(".xaxaxdad").hide();
    });
});




// australiya
$(document).ready(function () {
    $(".australia ").click(function () {
        $(".three_contry ").slideToggle("slow");
    });
    // java script
    $(".select_li ").click(function () {
        var selected = $(this).text();
        $(".select_text").text(selected);
    });


    // menubar
    // var windowwidth = $(window).width();

    // var containewidth = $("header .container").width();

    // var marginleftwidth = (windowwidth - containewidth) / 2;
    // $(".mega_menu_first").css("marginLeft", - marginleftwidth);
});

// header
$(window).scroll(function () {
    if ($(window).scrollTop() > 100) {
        $("body").addClass("head-fix");
    } else {
        $("body").removeClass("head-fix");
    }

    if ($(window).scrollTop() > 200) {
        $("body").addClass("anime-fix")
    } else {
        $("body").removeClass("anime-fix")
    }
});
// 3 dots
$(window).scroll(function () {
    if ($(window).scrollTop() > 100) {
        $(".three_dot_logo_par").css("display", "block");
    } else {
        $(".three_dot_logo_par").css("display", "none");
    }

    if ($(window).scrollTop() > 200) {
        $(".three_dot_logo_par").css("display", "block")
    } else {
        $(".three_dot_logo_par").css("display", "none")
    }
});

// owl mega menu's
$('.starting-one-carousel').owlCarousel({
    loop: false,
    // margin: 10,
    responsiveClass: true,
    autoplay: true,
    dots: true,
    lazyLoad: true,
    nav: false,
    responsive: {
        212: {
            items: 1,
            nav: false,
            loop: true
        }
    }
});
// x

$('.starting-one-carouselx').owlCarousel({
    loop: false,
    // margin: 10,
    responsiveClass: true,
    autoplay: true,
    dots: true,
    lazyLoad: true,
    nav: false,
    responsive: {
        212: {
            items: 1,
            nav: false,
            loop: true
        }
    }
});


$('.starting-one-carousel').owlCarousel({
    loop: false,
    // margin: 10,
    responsiveClass: true,
    autoplay: true,
    dots: true,
    lazyLoad: true,
    nav: false,
    responsive: {

        212: {
            items: 1,
            nav: false,
            loop: true
        }
    }
})
// banner section
$('.banner_owl_carousal').owlCarousel({
    loop: true,
    margin: 10,
    dots: true,
    animateOut: 'fadeOut',
    // animateIn: 'fadeIn', 
    responsiveClass: true,
    autoplayTimeout: 5000,
    autoplay: false,
    responsive: {
        1000: {
            items: 1,
            nav: true,
            loop: true
        },
        800: {
            items: 1,
            navText: false,
            nav: true,
            loop: true
        },
        320: {
            items: 1,
            nav: true,
            loop: true,
            navText: false
        }
    }
});
// small img carousal
$('.small_right_sides_owl').owlCarousel({
    loop: true,
    dots: false,
    navText: ['<span><img src="./assets/image/left-chevron.png" alt=""></span>', '<span><img src="./assets/image/chevron.png" alt=""></span>'],
    responsiveClass: true,
    autoplay: false,
    responsive: {
        1200: {
            items: 5,
            nav: true,
            loop: false
        },
        992: {
            items: 4,
            nav: true,
            loop: false
        },
        768: {
            items: 4,
            nav: true,
            loop: false
        },
        666: {
            items: 3,
            nav: true,
            loop: false
        },
        520: {
            items: 3,
            nav: true,
            loop: false
        },
        400: {
            items: 2,
            nav: false,
            loop: false
        },
        380: {
            items: 2,
            nav: false,
            loop: false
        },
        320: {
            items: 1,
            nav: false,
            loop: false
        }


    }
});

// hove to change image

$('.flase_best_seller').owlCarousel({
    loop: true,
    dots: true,
    margin: 10,
    navText: ['<span><img src="./assets/image/left-chevron.png" alt=""></span>', '<span><img src="./assets/image/chevron.png" alt=""></span>'],
    responsiveClass: true,
    autoplay: false,
    slideBy: 3,
    responsive: {
        1200: {
            items: 3,
            nav: true,
            loop: false
        },
        1000: {
            items: 3,
            nav: true,
            loop: false
        },
        850: {
            items: 3,
            nav: true,
            loop: false
        },
        700: {
            items: 2,
            nav: true,
            loop: false
        },
        576: {
            items: 2,
            nav: true,
            loop: false
        },
        450: {
            items: 2,
            nav: true,
            loop: false
        },
        320: {
            items: 1,
            nav: true,
            loop: false
        }
    }
});

$('.flase_best_seller_two').owlCarousel({
    loop: true,
    dots: true,
    navText: ['<span><img src="./assets/image/left-chevron.png" alt=""></span>', '<span><img src="./assets/image/chevron.png" alt=""></span>'],
    responsiveClass: true,
    autoplay: false,
    responsive: {
        1200: {
            items: 1,
            nav: true,
            loop: false
        },
        1000: {
            items: 1,
            nav: true,
            loop: false
        }
    }
});

// futured catagories

$('.parents_of_futured_sec').owlCarousel({
    loop: true,
    margin: 22,
    dots: true,
    navText: ['<span><img src="./assets/image/left-chevron.png" alt=""></span>', '<span><img src="./assets/image/chevron.png" alt=""></span>'],
    responsiveClass: true,
    autoplay: false,
    responsive: {
        1200: {
            items: 3,
            nav: true,
            loop: false
        },
        700: {
            items: 2,
            nav: false,
            loop: false
        },
        320: {
            items: 1,
            nav: false,
            loop: false
        }
    }
});

// nav owl
$('.flase_best_sellernav').owlCarousel({
    loop: true,
    dots: true,
    margin: 10,
    navText: ['<span><img src="./assets/image/left-chevron.png" alt=""></span>', '<span><img src="./assets/image/chevron.png" alt=""></span>'],
    responsiveClass: true,
    autoplay: false,
    slideBy: 3,
    responsive: {
        1200: {
            items: 3,
            nav: true,
            loop: false
        },
        1000: {
            items: 3,
            nav: false,
            loop: false
        },
        850: {
            items: 3,
            nav: false,
            loop: false
        },
        700: {
            items: 2,
            nav: false,
            loop: false
        },
        576: {
            items: 2,
            nav: false,
            loop: false
        },
        480: {
            items: 1,
            nav: false,
            loop: false
        },
        320: {
            items: 1,
            nav: false,
            loop: false
        }
    }
});


$('.owlthreethree').owlCarousel({
    loop: true,
    margin: 22,
    slideBy: 3,
    dots: true,
    navText: ['<span><img src="./assets/image/left-chevron.png" alt=""></span>', '<span><img src="./assets/image/chevron.png" alt=""></span>'],
    responsiveClass: true,
    autoplay: false,
    responsive: {
        1200: {
            items: 3,
            nav: true,
            loop: false
        },
        700: {
            items: 2,
            nav: false,
            loop: false
        },
        320: {
            items: 1,
            nav: false,
            loop: false
        }
    }
});


// add remove class
$(document).ready(function () {
    $(".rajasahi").click(function () {
        $(".rajasahi").removeClass("myaddremoveclass");
        $(this).addClass("myaddremoveclass");
    });
});