// all catagary
$(document).ready(function () {
    $('.button-of-show-more span').click(function () {
        $('.extra-div-parent-for-show-more').slideDown()
        $('.button-of-show-less span').show(100);
    })
    $('.button-of-show-less span').click(function () {
        $('.extra-div-parent-for-show-more').slideUp()
        $('.button-of-show-less span').hide(100);
    })
    $(".plus-click-event-for").hide();
    $(".brous-all-categories a").click(function () {
        $(".plus-click-event-for").toggle();
    });
});


$('.starting-one-carousel').owlCarousel({
    loop: false,
    margin: 10,
    responsiveClass: true,
    // autoplay: true,
    dots: true,
    lazyLoad:true,
    nav: false,
    animateOut: 'fadeOut', 
    animateIn: 'fadeIn', 
    responsive: {
        0: {
            items: 1,
            nav: false,
            loop: true

        },
        600: {
            items: 1,
            nav: false,
            loop: true

        },
        1000: {
            items: 1,
            nav: false,
            loop: true
        }
    }
})

$('.ressonsive-eleven-image-name-items').owlCarousel({
    loop: true,
    margin: 10,
    responsiveClass: true,
    dots: false,
    autoplay: true,
    nav: false,
    navText: ['<span><i class="fa-solid fa-arrow-right"></i></span>', '<span><i class="fa-solid fa-arrow-left"></i></span>'],
    responsive: {
        320: {
            items: 2,
            nav: true,
            loop: true
        },
        400: {
            items: 3,
            nav: true,
            loop: true
        },
        450: {
            items: 4,
            nav: true,
            loop: true
        },
        576: {
            items: 5,
            nav: true,
            loop: true
        },
        768: {
            items: 7,
            nav: false,
        },
        800:{
            items: 6,
            nav: false,
        },
        960: {
            items: 7,
            nav: false,
        },
        991: {
            items: 8,
            nav: false,
        },
        1000: {
            items: 8,
            nav: false,
            loop: true,
        },
        1100: {
            items: 9,
            nav: false,
            loop: true,
        },
        1200: {
            items: 10,
            nav: false,
            loop: true,
        }
    }
})

$('.slider-third-daily-best-sale').owlCarousel({
    loop: true,
    margin: 10,
    responsiveClass: true,
    dots: false,
    autoplay: false,
    responsive: {
        300: {
            items: 1,
            nav: true,
            loop: true,
        },
        400: {
            items: 1,
            nav: true,
            loop: true,
        },
        
        576: {
            items: 2,
            loop: true,
            nav: true,
        },
        700: {
            items: 3,
            nav: false,
            loop: true,
        },
        800: {
            items: 4,
            nav: false,
            loop: true,
        },
        900: {
            items: 4,
            nav: false,
            loop: true,
        },
        1000: {
            items: 5,
            nav: true,
            loop: true
        }
    }
})

// headb fix
$(window).scroll(function () {
    if ($(window).scrollTop() > 300) {
        $("body").addClass("head-fix");
    } else {
        $("body").removeClass("head-fix");
    }

    if ($(window).scrollTop() > 500) {
        $("body").addClass("anime-fix")
    } else {
        $("body").removeClass("anime-fix")
    }
});


// arrow up
$(document).ready(function () {
    $(window).scroll(function () {
        if ($(window).scrollTop() > 300) {
            $('.scroll-arrow').css('visibility', 'visible');
        } else {
            $('.scroll-arrow').css('visibility', 'hidden');
        }
    });
    $('.scroll-arrow').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 100); 
    });
    // loader
    $("#loader").fadeOut(1000, function () {
    });
});

// counter
window.onload = function() {
    $('.counter-value').each(function(){
        $(this).prop('Counter',10).animate({
            Counter: $(this).text()
        },{
            duration: 25000,
            easing: 'swing',
            step: function (now){
                $(this).text(Math.ceil(now));
            }
        });
    });
}
